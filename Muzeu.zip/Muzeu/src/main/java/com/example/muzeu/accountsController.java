package com.example.muzeu;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

public class accountsController {

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private TableView<doubleString> tabel;
    @FXML
    private TableColumn<doubleString, String> dsNume;
    @FXML
    private TableColumn<doubleString, String> dsDrepturi;
    ArrayList<doubleString> tabel2 = new ArrayList<doubleString>();

    @FXML
    protected void update(ActionEvent event) throws Exception {

        System.out.println("Updated!");
        FXMLLoader loader=new FXMLLoader(getClass().getResource("accounts.fxml"));
        root=loader.load();

        accountsController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    protected void editareCont(ActionEvent event) throws Exception {
        if(tabel.getSelectionModel().getSelectedItem()!=null) {
            if (utilizatori.getCurrent().getUSER().equals(tabel.getSelectionModel().getSelectedItem().getS1()) == false) {
                System.out.println("Edit!");
                FXMLLoader loader2 = new FXMLLoader(getClass().getResource("editare-cont.fxml"));
                Parent root2 = loader2.load();

                editareController log = loader2.getController();
                log.startup(tabel.getSelectionModel().getSelectedItem().getS1());

                Scene scene2 = new Scene(root2, 221, 347);
                Stage stage2 = new Stage();
                stage2.setScene(scene2);
                stage2.show();

            }
        }
    }
    @FXML
    protected void contNou(ActionEvent event) throws Exception {
        System.out.println("Cont nou!");
        FXMLLoader loader2=new FXMLLoader(getClass().getResource("cont-nou.fxml"));
        Parent root2=loader2.load();

        contNouController log=loader2.getController();

        Scene scene2=new Scene(root2, 221, 347);
        Stage stage2=new Stage();
        stage2.setScene(scene2);
        stage2.show();
    }
    @FXML
    protected void meniuLogged(ActionEvent event) throws Exception {
        System.out.println("Logged out");

        FXMLLoader loader=new FXMLLoader(getClass().getResource("logged.fxml"));
        root=loader.load();

        loggedController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void startup()
    {

        dsNume.setCellValueFactory(new PropertyValueFactory<>("s1"));

        dsDrepturi.setCellValueFactory(new PropertyValueFactory<>("s2"));

        tabel2 = new ArrayList<doubleString>();
        tabel.getItems().clear();

        Connection dbconn = DBConnection.connectDB();
        if (dbconn != null) {
            try {

                PreparedStatement st = (PreparedStatement) dbconn.prepareStatement("Select * from utilizatori");
                ResultSet rs = st.executeQuery();
                while (rs.next()) {
                    tabel2.add(new doubleString(rs.getString("USER"),utilizatori.dreptText(rs.getInt("drepturi"))));
                }
            } catch (Exception ex) {
                System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
            }
        }

        System.out.println("nice");

        for(doubleString i : tabel2)
            tabel.getItems().add(i);
    }
}
