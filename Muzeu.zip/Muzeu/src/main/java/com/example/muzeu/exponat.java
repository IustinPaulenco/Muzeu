package com.example.muzeu;

public class exponat {
    private int id,an,anPrimire;
    vitrina vit;
    private String nume,locatie;


    exponat(){}
    exponat(int id)
    {
        this.id=id;
    }
    exponat(int id, int an,int anPrimire,vitrina vit,String nume,String locatie)
    {
        this.id=id;
        this.nume=nume;
        this.an=an;
        this.locatie=locatie;
        this.anPrimire=anPrimire;
        this.vit=vit;
    }

    int getId() {
        return id;
    }
    String getNume(){
        return nume;
    }
    int getAn() {
        return an;
    }
    String getLocatie(){
        return locatie;
    }
    int getAnPrimire(){
        return anPrimire;
    }
    vitrina getVitrina(){
        return vit;
    }
    void setNume(String a){
        this.nume=a;
    }
    void setAn(int a){
        this.an=a;
    }
    void setLocatie(String a){
        this.locatie=a;
    }
    void setAnPrimire(int a){
        this.anPrimire=a;
    }
    void setVitrina(vitrina a){
        this.vit=a;
    }
}
