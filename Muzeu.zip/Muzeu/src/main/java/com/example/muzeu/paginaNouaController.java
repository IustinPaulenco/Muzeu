package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class paginaNouaController {

    private Stage stage,storedStage;
    private Scene scene;
    private Parent root;
    private String user;
    @FXML
    private TextField nume;

    @FXML protected void Apply(ActionEvent event) throws Exception {
        if (nume.getText().length() != 0) {

            Connection dbconn = DBConnection.connectDB();
            PreparedStatement st = (PreparedStatement)
                    dbconn.prepareStatement("Select * from pagina WHERE NUME = ?");
            st.setString(1, nume.getText());
            ResultSet rs = st.executeQuery();

            if (!rs.next()) {
                try {

                                st = dbconn.prepareStatement("INSERT INTO pagina VALUES (?, ?, ?);");
                                st.setString(1, nume.getText());
                                st.setString(2, utilizatori.getCurrent().getUSER());
                                st.setString(3, "");
                                st.executeUpdate();


                        FXMLLoader loader = new FXMLLoader(getClass().getResource("ok.fxml"));
                        Parent root2 = loader.load();
                        Scene scene2 = new Scene(root2, 156, 95);
                        Stage stage2 = new Stage();
                        stage2.setTitle("");
                        stage2.setScene(scene2);
                        stage2.show();

                        okController log = loader.getController();
                        log.mesaj("Pagina a fost creata cu succes!");

                        ((Stage) nume.getScene().getWindow()).close();
                } catch (Exception ex) {
                    //System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
                }
            }
        }
    }

}
