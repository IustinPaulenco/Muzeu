package com.example.muzeu;

import java.sql.*;
public class DBConnection {

    static final String DB_URL = "jdbc:mysql://localhost:3306/exponat";
    static final String USER = "root";
    static final String PASS = "0000";
    public static Connection connectDB()
    {
        Connection conn = null;
        try {
            //Class.forName("com.mysql.jdbc,Driver");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
            return conn;
        }catch(Exception ex){
            System.out.println("There were errors while connecting to the database");
            return null;
        }

    }



}