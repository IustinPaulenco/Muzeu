package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Objects;
import java.util.Scanner;

public class loggedController {

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private Label ConnectedText;
    @FXML
    private Button manage;
    @FXML
    private TextField pp;

    @FXML
    protected void meniuPrincipalLogin(ActionEvent event) throws Exception {
        System.out.println("Logged out");

        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("login.fxml")));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    protected void schimbaParola(ActionEvent event) throws Exception {
        Parent root2=FXMLLoader.load(HelloApplication.class.getResource("schimbare-parola.fxml"));
        Scene scene2=new Scene(root2, 200, 300);
        Stage stage2=new Stage();
        stage2.setTitle("");
        stage2.setScene(scene2);
        stage2.show();
    }


    @FXML
    protected void manager(ActionEvent event) throws Exception {
        System.out.println("Manager!");
        FXMLLoader loader=new FXMLLoader(getClass().getResource("accounts.fxml"));
        root=loader.load();

        accountsController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    protected void pagini(ActionEvent event) throws Exception {
        System.out.println("Pagini!");
        FXMLLoader loader=new FXMLLoader(getClass().getResource("pagini.fxml"));
        root=loader.load();

        paginiController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void schimba(ActionEvent event)
    {
        try {
            FileWriter writer = new FileWriter("C:/pagini/config/default.txt");
            writer.write(pp.getText());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void startup() {

        ConnectedText.setText("V-ați conectat pe contul: " + utilizatori.getCurrent().getUSER());
        if(utilizatori.getCurrent().getDrepturi()<3)
        {
            manage.setVisible(false);
        }
        try {
            String contents=new String();
            File file = new File("C:/pagini/config/default.txt");
            Scanner scanner = new Scanner(file);
            if (scanner.hasNextLine()) {
                contents += scanner.nextLine();
            }
            scanner.close();
            pp.setText(contents);
        } catch (Exception e) {}
    }
}
