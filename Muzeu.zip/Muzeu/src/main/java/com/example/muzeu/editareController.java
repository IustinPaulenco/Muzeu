package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class editareController {

    private Stage stage,storedStage;
    private Scene scene,storedScene;
    private Parent root;
    private String user;
    @FXML
    private TextField func;
    @FXML
    private TextField passwordField;
    @FXML
    private TextField passwordConf;
    @FXML
    private Label mesajEroareParola;
    @FXML
    private Label username;

    @FXML protected void Apply(ActionEvent event) throws Exception {
        Connection dbconn = DBConnection.connectDB();
        boolean Logged=false;
        if (dbconn != null) {
            try {
                int rowsAffected=1;
                if(func.getText().length()!=0) rowsAffected=(Integer.parseInt(func.getText())>=0&&Integer.parseInt(func.getText())<=3)?1:0;
                if(rowsAffected==1) {
                    PreparedStatement st = (PreparedStatement)
                            dbconn.prepareStatement("Select * from utilizatori WHERE USER = ?");
                    st.setString(1, user);
                    ResultSet rs = st.executeQuery();

                    if (rs.next()) {
                        if (passwordField.getText().length() != 0 && passwordConf.getText().length() != 0) {
                            if (passwordField.getText().equals(passwordConf.getText()) && passwordField.getText().length() >= 4) {
                                st = dbconn.prepareStatement("Update utilizatori Set PASS = ? Where USER = ?");
                                st.setString(1, passwordField.getText());
                                st.setString(2, user);
                                rowsAffected = st.executeUpdate();

                                if (rowsAffected == 0) {
                                    mesajEroareParola.setVisible(true);
                                    mesajEroareParola.setText("Parola este gresita!");
                                }
                            } else {
                                mesajEroareParola.setVisible(true);
                                mesajEroareParola.setText("Parola noua nu corespunde!");
                            }
                        } else rowsAffected = 1;
                        if (func.getText().length() != 0 && rowsAffected == 1) {
                            st = dbconn.prepareStatement("Update utilizatori Set drepturi = ? Where USER = ?");
                            st.setString(1, Integer.toString(Integer.parseInt(func.getText())));
                            st.setString(2, user);
                            st.executeUpdate();
                        }
                    }
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("ok.fxml"));
                    Parent root2 = loader.load();
                    Scene scene2 = new Scene(root2, 156, 95);
                    Stage stage2 = new Stage();
                    stage2.setTitle("");
                    stage2.setScene(scene2);
                    stage2.show();

                    okController log = loader.getController();
                    log.mesaj("Modificarile au fost facute cu succes!");

                    ((Stage) mesajEroareParola.getScene().getWindow()).close();
                }
                else
                {
                    mesajEroareParola.setVisible(true);
                    mesajEroareParola.setText("Functia este invalida!");
                }
            } catch (Exception ex) {
                //System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
            }
        }
        else
        {
            if(!Logged)
            {
                mesajEroareParola.setVisible(true);
            }
        }
    }
    public void startup(String s)
    {
        user=s;
        username.setText(s);
    }

}
