package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

public class paginiController {

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private TableView<doubleString> tabel;
    @FXML
    private TableColumn<doubleString, String> ds1;
    @FXML
    private TableColumn<doubleString, String> ds2;
    ArrayList<doubleString> tabel2 = new ArrayList<doubleString>();

    @FXML
    protected void update(ActionEvent event) throws Exception {

        System.out.println("Updated!");
        FXMLLoader loader=new FXMLLoader(getClass().getResource("pagini.fxml"));
        root=loader.load();

        paginiController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    protected void editarePagina(ActionEvent event) throws Exception {
        if(tabel.getSelectionModel().getSelectedItem()!=null&&(tabel.getSelectionModel().getSelectedItem().s1.equals(utilizatori.getCurrent().getUSER())||utilizatori.getCurrent().getDrepturi()>1)) {
                System.out.println("Edit!");

                FXMLLoader loader=new FXMLLoader(getClass().getResource("edit-pagina.fxml"));
                root=loader.load();

                editPaginaController log=loader.getController();

                String link="";
                Connection dbconn = DBConnection.connectDB();
                if (dbconn != null) {
                    try {

                        PreparedStatement st = (PreparedStatement) dbconn.prepareStatement("Select * from pagina where NUME = ?");
                        st.setString(1, tabel.getSelectionModel().getSelectedItem().s1);
                        ResultSet rs = st.executeQuery();
                        if (rs.next()) {

                            link=rs.getString("LINK");
                        }
                    } catch (Exception ex) {
                        System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
                    }
                }

                log.startup(tabel.getSelectionModel().getSelectedItem().s1,link);

                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();

        }
    }
    @FXML
    protected void paginaNoua(ActionEvent event) throws Exception {
        System.out.println("pagina noua!");
        FXMLLoader loader2=new FXMLLoader(getClass().getResource("pagina-noua.fxml"));
        Parent root2=loader2.load();

        paginaNouaController log=loader2.getController();

        Scene scene2=new Scene(root2, 221, 166);
        Stage stage2=new Stage();
        stage2.setScene(scene2);
        stage2.show();
    }
    @FXML
    protected void meniuLogged(ActionEvent event) throws Exception {
        System.out.println("Logged out");

        FXMLLoader loader=new FXMLLoader(getClass().getResource("logged.fxml"));
        root=loader.load();

        loggedController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void startup()
    {

        ds1.setCellValueFactory(new PropertyValueFactory<>("s1"));

        ds2.setCellValueFactory(new PropertyValueFactory<>("s2"));

        tabel2 = new ArrayList<doubleString>();
        tabel.getItems().clear();

        Connection dbconn = DBConnection.connectDB();
        if (dbconn != null) {
            try {

                PreparedStatement st = (PreparedStatement) dbconn.prepareStatement("Select * from pagina");
                ResultSet rs = st.executeQuery();
                while (rs.next()) {

                    tabel2.add(new doubleString(rs.getString("NUME"),rs.getString("USER")));
                }
            } catch (Exception ex) {
                System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
            }
        }

        System.out.println("nice");

        for(doubleString i : tabel2)
            tabel.getItems().add(i);
    }
}
