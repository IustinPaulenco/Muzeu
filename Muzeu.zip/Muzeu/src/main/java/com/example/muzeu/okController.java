package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class okController {

    @FXML
    private Label mesajOk;
    @FXML
    protected void lasaMaOdataInPace(ActionEvent event) throws Exception {
        ((Stage)mesajOk.getScene().getWindow()).close();
    }
    public void mesaj(String s) {
        mesajOk.setText(s);
    }

}
