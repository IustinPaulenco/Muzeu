package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Objects;

public class passwordController {

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private TextField oldPasswordField;
    @FXML
    private TextField newPasswordField;
    @FXML
    private TextField passwordConf;
    @FXML
    private Label mesajEroareParola;

    @FXML protected void schimbaParola(ActionEvent event) throws Exception {
        System.out.println("Ai schimbat parola");
        Connection dbconn = DBConnection.connectDB();
        boolean Logged=false;
        if (dbconn != null) {
            try {

                PreparedStatement st = (PreparedStatement)
                        dbconn.prepareStatement("Select * from utilizatori WHERE USER = ? AND PASS = ?");
                st.setString(1, utilizatori.getCurrent().getUSER());
                st.setString(2, oldPasswordField.getText());
                ResultSet rs = st.executeQuery();

                if (rs.next()) {
                    if(newPasswordField.getText().equals(passwordConf.getText())&&newPasswordField.getText().length()>=4)
                    {
                        st=dbconn.prepareStatement("Update utilizatori Set PASS = ? Where USER = ? AND PASS = ?");
                        st.setString(1, newPasswordField.getText());
                        st.setString(2, utilizatori.getCurrent().getUSER());
                        st.setString(3, oldPasswordField.getText());
                        int rowsAffected = st.executeUpdate();

                        if (rowsAffected == 0) {
                            mesajEroareParola.setVisible(true);
                            mesajEroareParola.setText("Parola este gresita!");
                        } else {
                            utilizatori.setCurrent(new utilizatori(utilizatori.getCurrent().getDrepturi(),utilizatori.getCurrent().getUSER(),newPasswordField.getText()));

                            FXMLLoader loader=new FXMLLoader(getClass().getResource("ok.fxml"));
                            Parent root2=loader.load();
                            Scene scene2=new Scene(root2, 156, 95);
                            Stage stage2=new Stage();
                            stage2.setTitle("");
                            stage2.setScene(scene2);
                            stage2.show();

                            okController log=loader.getController();
                            log.mesaj("Ai schimbat parola cu succes!");


                            ((Stage)mesajEroareParola.getScene().getWindow()).close();
                        }
                    }else {
                        mesajEroareParola.setVisible(true);
                        mesajEroareParola.setText("Parola noua nu corespunde!");
                    }
                } else {
                    mesajEroareParola.setVisible(true);
                    mesajEroareParola.setText("Parola este gresita!");
                }
            } catch (Exception ex) {
                //System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
            }
        }
        else
        {
            if(!Logged)
            {
                mesajEroareParola.setVisible(true);
            }
        }
    }

}
