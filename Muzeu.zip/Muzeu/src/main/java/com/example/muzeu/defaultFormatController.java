package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class defaultFormatController {

    private Image img2=new Image(getClass().getResourceAsStream("no-image-png-2.png"));
    private Image img=img2;
    private String nume;
    private String imgpath;
    @FXML
    private TextArea text;
    @FXML
    private ImageView image;
    @FXML
    private Label titlu;

    @FXML
    protected void back(ActionEvent event) throws Exception {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root=loader.load();

        HelloController log=loader.getController();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void startup(String s,String i) throws Exception
            {
                titlu.setText(s);
                if(i!=null&&!i.equals(""))
                {
                    try
                    {
                        img=new Image(getClass().getResourceAsStream("resurse/imagini/"+i));
                        image.setImage(img);
                    }
                    catch (Exception e) {}

                }
                try {
                    String contents=new String();
                    File file = new File("C:/pagini/"+s+".txt");
                    Scanner scanner = new Scanner(file);
                    while (scanner.hasNextLine()) {
                        contents += scanner.nextLine() + "\n";
                    }
                    scanner.close();
                    text.setText(contents);
                } catch (Exception e) {}
            }
}
