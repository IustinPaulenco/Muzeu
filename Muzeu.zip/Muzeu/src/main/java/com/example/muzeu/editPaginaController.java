package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class editPaginaController {

    private Image img2=new Image(getClass().getResourceAsStream("no-image-png-2.png"));
    private Image img=img2;
    private Stage stage;
    private Scene scene;
    private Parent root;
    private String nume;
    private String imgpath;
    @FXML
    private TextArea text;
    @FXML
    private ImageView image;
    @FXML
    private TextField link;

    @FXML
    protected void back(ActionEvent event) throws Exception {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("pagini.fxml"));
        root=loader.load();

        paginiController log=loader.getController();
        log.startup();

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    protected void loadImage(ActionEvent event) throws Exception {
        img=img2;
        try
        {
            img=new Image(getClass().getResourceAsStream("resurse/imagini/"+link.getText()));
            imgpath=link.getText();
        }
        catch (Exception e) {}
        image.setImage(img);
    }
    @FXML
    protected void save(ActionEvent event) throws Exception {
        try {
            FileWriter writer = new FileWriter("C:/pagini/"+nume+".txt");
            writer.write(text.getText());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(link.getText().length()!=0)
        {
            Connection dbconn = DBConnection.connectDB();
            PreparedStatement st = dbconn.prepareStatement("Update pagina Set LINK = ? Where NUME = ?");
            st.setString(1, imgpath);
            st.setString(2, nume);
            st.executeUpdate();
        }
    }

    public void startup(String s,String i) throws Exception
    {
        nume=s;
        if(i!=null&&!i.equals(""))
        {
            try
            {
                img=new Image(getClass().getResourceAsStream("resurse/imagini/"+i));
                imgpath=i;
                image.setImage(img);
                link.setText(i);
            }
            catch (Exception e) {}

        }
        try {
            String contents=new String();
            File file = new File("C:/pagini/"+nume+".txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                contents += scanner.nextLine() + "\n";
            }
            scanner.close();
            text.setText(contents);
        } catch (Exception e) {}
    }
}
