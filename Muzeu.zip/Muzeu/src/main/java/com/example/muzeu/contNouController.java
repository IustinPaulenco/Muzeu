package com.example.muzeu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class contNouController {

    private Stage stage,storedStage;
    private Scene scene;
    private Parent root;
    private String user;
    @FXML
    private TextField func;
    @FXML
    private TextField passwordField;
    @FXML
    private TextField passwordConf;
    @FXML
    private Label mesajEroareParola;
    @FXML
    private TextField usernameField;

    @FXML protected void Apply(ActionEvent event) throws Exception {
        if (func.getText().length() != 0 && passwordConf.getText().length() != 0 && passwordField.getText().length() != 0 && usernameField.getText().length() != 0) {

            Connection dbconn = DBConnection.connectDB();
            PreparedStatement st = (PreparedStatement)
                    dbconn.prepareStatement("Select * from utilizatori WHERE USER = ?");
            st.setString(1, user);
            ResultSet rs = st.executeQuery();

            if (!rs.next()) {
                try {
                    int rowsAffected = 1;
                    rowsAffected = (Integer.parseInt(func.getText()) >= 0 && Integer.parseInt(func.getText()) <= 3) ? 1 : 0;
                    if (rowsAffected == 1) {

                        if (passwordField.getText().length() != 0 && passwordConf.getText().length() != 0) {
                            if (passwordField.getText().equals(passwordConf.getText()) && passwordField.getText().length() >= 4) {
                                    st = dbconn.prepareStatement("INSERT INTO utilizatori VALUES (?, ?, ?);");
                                    st.setString(1, usernameField.getText());
                                    st.setString(2, passwordField.getText());
                                    st.setString(3, Integer.toString(Integer.parseInt(func.getText())));
                                    st.executeUpdate();
                            } else {
                                mesajEroareParola.setVisible(true);
                                mesajEroareParola.setText("Parola nu corespunde!");
                            }
                        }

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("ok.fxml"));
                        Parent root2 = loader.load();
                        Scene scene2 = new Scene(root2, 156, 95);
                        Stage stage2 = new Stage();
                        stage2.setTitle("");
                        stage2.setScene(scene2);
                        stage2.show();

                        okController log = loader.getController();
                        log.mesaj("Contul a fost creat cu succes!");

                        ((Stage) mesajEroareParola.getScene().getWindow()).close();
                    } else {
                        mesajEroareParola.setVisible(true);
                        mesajEroareParola.setText("Functia este invalida!");
                    }
                } catch (Exception ex) {
                    //System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
                }
            } else {
                mesajEroareParola.setVisible(true);
                mesajEroareParola.setText("Contul deja exista!");
            }
        }
        else
        {
            mesajEroareParola.setVisible(true);
            mesajEroareParola.setText("Toate câmpurile trebuie completate!");
        }
    }

}
