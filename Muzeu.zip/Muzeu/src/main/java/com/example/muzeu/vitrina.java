package com.example.muzeu;

public class vitrina {
    int id;
    String incapere;
    exponat exponate[];


}
