package com.example.muzeu;

public class utilizatori {
    private String USER;
    private String PASS;
    private int drepturi;

    private static utilizatori current;

    utilizatori(){};
    utilizatori(int d,String u,String p){
        this.drepturi=d;
        this.USER=u;
        this.PASS=p;
    };

    public static utilizatori getCurrent() {
        if (current == null) {
            current = new utilizatori();
        }
        return current;
    }
    public static void setCurrent(utilizatori u) {
        current = u;
    }

    public int getDrepturi()
    {
        return this.drepturi;
    }
    public String getUSER()
    {
        return this.USER;
    }
    public boolean log(String u, String p)
    {
        if(u.compareTo(this.USER)==0&&p.compareTo(this.PASS)==0)
            return true;
        return false;
    }
    public static String dreptText(int drepturi)
    {
        if(drepturi==0)
            return "Cont dezactivat";
        else if(drepturi==1)
            return "Creeare de articole";
        else if(drepturi==2)
            return "Creeare și editare de articole";
        else
        return "Creeare și editare de articole, Management conturi";
    }
}
