package com.example.muzeu;

import com.sun.javafx.charts.Legend;
import com.sun.javafx.scene.text.TextSpan;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.File;
import java.sql.*;
import java.util.Objects;
import java.util.Scanner;

public class HelloController {

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private Label wrongPassText;

    @FXML
    private TextField passwordField;
    @FXML
    private TextField usernameField;

    @FXML
    protected void meniuPrincipalVizualizare(ActionEvent event) throws Exception {
        System.out.println("Intrăm pe vizualizare din meniu");

        FXMLLoader loader=new FXMLLoader(getClass().getResource("default-format.fxml"));
        root=loader.load();

        defaultFormatController log=loader.getController();
        ResultSet rs;
        String nume="Test";
        String link="logo";
        try {
            Connection dbconn = DBConnection.connectDB();
            PreparedStatement st = (PreparedStatement) dbconn.prepareStatement("Select * from pagina where NUME = ?");
            String contents=new String();
            File file = new File("C:/pagini/config/default.txt");
            Scanner scanner = new Scanner(file);
            if (scanner.hasNextLine()) {
                contents += scanner.nextLine();
            }
            scanner.close();
            st.setString(1, contents);
            rs = st.executeQuery();
            if (rs.next()) {

                nume=rs.getString("NUME");
                link=rs.getString("LINK");
            }
        } catch (Exception ex) {
            System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
        }
        log.startup(nume,link);

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void meniuPrincipalLogin(ActionEvent event) throws Exception {
        System.out.println("Intrăm pe login din meniu");

        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("login.fxml")));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void meniuPrincipalLogged(ActionEvent event) throws Exception {
        Connection dbconn = DBConnection.connectDB();
        boolean Logged=false;
        if (dbconn != null) {
            try {

                PreparedStatement st = (PreparedStatement)
                        dbconn.prepareStatement("Select * from utilizatori WHERE USER = ? AND PASS = ?");
                st.setString(1, usernameField.getText()/*String.valueOf(usernameField)*/);
                st.setString(2, passwordField.getText()/*String.valueOf(passwordField)*/);
                //System.out.println("E bine dacă programul scrie acest mesaj");
                ResultSet rs = st.executeQuery();

                if (rs.next()) {
                    if(rs.getInt("drepturi")==0)
                    {
                        wrongPassText.setText("Contul este dezactivat. Contactați administrația");
                        wrongPassText.setVisible(true);
                    }
                    else
                        Logged=true;
                } else {
                    wrongPassText.setVisible(true);
                    wrongPassText.setText("Utilizator/Parolă greșite!");
                }
            } catch (Exception ex) {
                System.out.println("Nu e prea bine dacă programul scrie acest mesaj");
            }
        }
        else
        {
            if(!Logged)
            {
                wrongPassText.setText("Utilizator/Parolă greșite!");
                wrongPassText.setVisible(true);
            }
        }
        if(Logged==true)
        {
            PreparedStatement st = (PreparedStatement)
                    dbconn.prepareStatement("SELECT * from utilizatori WHERE USER =?");
            st.setString(1, usernameField.getText());
            ResultSet resultSet = st.executeQuery();
            if(resultSet.next()) {
                utilizatori.setCurrent(new utilizatori(resultSet.getInt("drepturi"), usernameField.getText(), passwordField.getText()));
            }
            System.out.println("Logged In!");
            FXMLLoader loader=new FXMLLoader(getClass().getResource("logged.fxml"));
            root=loader.load();

            loggedController log=loader.getController();
            log.startup();

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        }
    }

    @FXML
    protected void meniuPrincipal(ActionEvent event) throws Exception {
        System.out.println("Intrăm in meniu");
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("hello-view.fxml")));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
